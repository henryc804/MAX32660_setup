Bootloader Downloader Host Firmware

1.5.2
---------------------------------
* Add msbl in RAM mode to support faster image flashing for Mass production
* Introduced image_on_ram and image_flash commands to support new flashing mode
* Reduced communication delays between MAX32660 bootloader and host 
* Disabled MFIO pin as default
* Minor fixes, optimizations, and refactoring codet log


