#ifndef __VERSION_H__
#define __VERSION_H__

#include "build_version.h"

#define FIRMWARE_VERSION       "1.5.5"

#endif
